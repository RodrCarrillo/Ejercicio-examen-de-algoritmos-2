import heapq
import csv
class Cola_de_prioridad:
    def __init__(self):
        self.pendientes = []
    def agregar(self, plazo_en_dias, tarea):
        heapq.heappush(self.pendientes, (plazo_en_dias, tarea))
    def extraer(self):
        return heapq.heappop(self.pendientes)[1]
    def ver_la_mas_urgente(self):
        primera = self.pendientes[0]
        print(primera)
    def extraer_todo(self):
            tareas_extraidas = []  
            while len(self.pendientes) != 0:
                tarea = heapq.heappop(self.pendientes)[1]
                tareas_extraidas.append(tarea)
                print(tareas_extraidas)  
            return tareas_extraidas 
     
    def tareas_de_la_semana(self, nombre_archivo):
        with open(nombre_archivo, mode='w', newline='', encoding='utf-8') as archivo:
            escritor = csv.writer(archivo)
            escritor.writerow(["prioridas", 'tarea'])  


cola = Cola_de_prioridad()
cola.agregar(1, "psiquiatra")
cola.agregar(3, "estudiar grafos")
cola.agregar(1, "estudiar algoritmos")
cola.agregar(2, "estudiar calculo")
cola.tareas_de_la_semana("registro_de_tareas")
#cola.extraer_todo() #si se extrae todo no se podra usar la funcion ver_la_mas_urgente
cola.ver_la_mas_urgente()

